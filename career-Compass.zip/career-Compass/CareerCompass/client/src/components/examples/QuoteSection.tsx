import QuoteSection from "../QuoteSection";

export default function QuoteSectionExample() {
  return <QuoteSection />;
}