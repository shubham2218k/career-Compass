import RoadmapSection from "../RoadmapSection";

export default function RoadmapSectionExample() {
  return <RoadmapSection />;
}